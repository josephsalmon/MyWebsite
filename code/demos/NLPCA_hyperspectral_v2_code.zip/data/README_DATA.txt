The Indian pines data is publically available from:
https://engineering.purdue.edu/~biehl/MultiSpec/hyperspectral.html

The .mat files of this data was obtained from:
http://www.ehu.eus/ccwintco/index.php?title=Hyperspectral_Remote_Sensing_Scenes