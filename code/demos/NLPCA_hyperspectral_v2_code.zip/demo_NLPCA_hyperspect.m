clear;

addpath('data')
addpath(genpath('functions'))

%% Image generation

load Indian_pines_corrected % Load data
f = indian_pines_corrected;
rng(1) % Random number generator using seed

ima_ori = 0.005*f(1:100,1:100,6:20); % Truth (crops image and multiplies by a number)
ima_nse_poiss = knuth_poissrnd(ima_ori); % Noisy Poisson image

[M,N,P] = size(ima_ori); % M, N, and P are the dimensions of the original image
n = sum(ima_nse_poiss(:))/(M*N*P); % Average intensity of noisy image
peak = max(max(ima_ori(:))); % Finds the max value in the original image

clear f


%% Parameters:

param.Patch_width = 5;
param.Patch_width_3d = 5; % number of spectral bands
param.nb_axis = 5;
param.nb_clusters = 20;

if isToolboxAvailable('Parallel Computing Toolbox','warning')
	param.parallel = 1; % 0/1 determines if parallelization is used
else 
	param.parallel = 0;
end

param.SPIRALTAP = 0; % 0/1 determines if Newton's method is used (0 is recommended)

param.eps_stop = 1e-1; % loop stopping criterion
param.epsilon_cond = 1e-3; % condition number for Hessian inversion
param.double_iteration = 0; % 1 or 2 pass of the whole algorithm
param.nb_iterations = 4;
param.bandwith_smooth = 2;
param.sub_factor = 2;
param.big_cluster1 = 1; % special case for the biggest cluster 1st pass
param.big_cluster2 = 1; % special case for the biggest cluster 2nd pass
param.cste = 70;
param.func_tau = @(X) lasso_tau(X{1},X{2},param.cste);


%% Computation (main method)

tic
ima_fil = denoise_poisson_kmeans_poisson_PCA_l1_4d_cube_3d(ima_nse_poiss,param); % Main function
toc


%% Error Calculation

sprintf('PSNR'); % peak signal noise ratio
psnr = psnr4d(ima_fil,ima_ori,255) % computes PSNR - higher is better
sprintf('MAE_L1'); % mean absolute error
MAE = MAE_L1(ima_fil,ima_ori) % computes MAE - lower is better


%% Display

if 1 % determines if the images should be displayed
    
    G(P) = struct('cdata',[],'colormap',[]);
    scrsz = get(0,'ScreenSize'); % gets screen size
    fh = figure('Position',[1 1 scrsz(1,3) scrsz(1,4)]);
    
    for j = 1:P
        
        subplot(1,3,1)
        imagesc(ima_ori(:,:,j));
        title(strcat('Original Band',32,num2str(j)))
        axis image; axis off; colorbar; colormap gray
        
        subplot(1,3,2)
        imagesc(ima_nse_poiss(:,:,j));
        title(strcat('Noisy Band',32,num2str(j)))
        axis image; axis off; colorbar; colormap gray
        
        subplot(1,3,3)
        imagesc(ima_fil(:,:,j));
        title(strcat('NLPCA Band',32,num2str(j)))
        axis image; axis off; colorbar; colormap gray
        
        pause(.2); % sets time between each frame display
        G(j) = getframe(fh);
    end
end