-----Introduction-----

Welcome! This will be a short guide to using Poisson NLPCA for 
hyperspectral images.

-----Demo file-----

"DEMO_NLPCA_hyperspect.m" - This file loads a test image, generates a 
noisy Poisson observation, and denoises the image.

-----Parameters-----

There are several important parameters that can be changed. These are 
located in "DEMO_NLPCA_hyperspect.m" starting on line 24.

1. param.Patch_width: This value must be smaller or equal to the X or Y 
dimension of the image. For example, if the test image is 100 by 200 by 
300, the largest "param.Patch_width" can be is 100. Picking a relatively 
large "param.Patch_width" might result in a blurry, hazy, overly smoothed 
image, and there will not be many details. However, picking a relatively 
small "param.Patch_width" might result in too many details, and there will 
not be much of the original image. 

2. param.Patch_width_3d: This value must be smaller or equal to the Z 
dimension of the image. For example, if the test image is 100 by 200 by 
300, the largest "param.Patch_width_3d" can be is 300.

3. param.nb_axis: This value determines how many axes are kept when 
denoising each cluster of patches. A larger value is not always better, 
because it might capture too much noise. A smaller value is not always 
better, because it might not capture enough signal. 

4. param.nb_clusters: This determines how many clusters the patches are 
grouped into.

Note: picking the 4 parameters above is sort of an art and will largely 
depend on which image is being denoised - it's best to experiment.

5. param.parallel: This determines if parallelization is used. "1" means 
it is used, and "0" means it is not. Using it can improve the speed of the 
code, depending on the number of cores the machine has. On consumer laptops
with 2 or 4 cores, the improvement may be noticable, but not a lot. 
However, on machines with many cores (say 12) the improvement can be 
significant. However, note that there is a initial "start-up" cost in time 
if parallelization is done.

6. param.SPIRALTAP: This determines if the Newton's method for subspace 
estimation is used (called SPIRALTAP, for Sparse Poisson Intensity 
Reconstruction ALgorithms). "1" means it is used, and "0" means it is not. 
Our initialization to this method generally works so well that it is 
recommended to keep this option off to save on computation time.

-----Other-----

Developed with MATLAB release name R2014b.

----------

Copyright (C) 2012 NL-PCA project

Joseph Salmon, Charles-Alban Deledalle, Rebecca Willet, Zachary Harmany

(This release revised by Anthony Wang, Albert Oh, and Rebecca Willett on 
May 28, 2015.)

See The GNU Public License (GPL)

This file is part of NL-PCA.

NL-PCA is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later 
version.

NL-PCA is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. You should have received a copy of the GNU General Public License 
along with NL-PCA.  If not, see <http://www.gnu.org/licenses/>.